#ifndef coindesk_h
#define coindesk_h
#include <ArduinoJson.h>
#include <Client.h>
class Coindesk
{
private:
    Client *client;
    String web_api;
    String output;
    const char *web_host;
    bool debug;
    unsigned long timeout;
public:
    Coindesk(Client &client, const char *_web_host, String &_web_api,bool debug,unsigned long timeout);
    void make_request();
    ~Coindesk();
    char* time_updated();
public:

    struct Data
    {
        char *time_updated;
        char *time_updatedISO;
        char *time_updateduk;
        char *disclaimer;
        char *chartname;
    };
    struct USD
    {
        char *code;
        char *symbol;
        char *rate_char;
        char *description;
        float rate_float;
    };
    struct GBP
    {
        char *code;
        char *symbol;
        char *rate_char;
        char *description;
        float rate_float;
    };
    struct EUR
    {
        char *code;
        char *symbol;
        char *rate_char;
        char *description;
        float rate_float;
    };
    USD usd;
    GBP gbp;
    EUR eur;
    Data data;

};
#endif